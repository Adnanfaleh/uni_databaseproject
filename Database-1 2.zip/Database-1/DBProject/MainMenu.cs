﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;  

namespace DBProject
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent(); 
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mmza1\source\repos\DBProject\DBProject\SMDB.mdf;Integrated Security=True;Connect Timeout=30;");


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void populate()
        {
            try
            {
                Con.Open();
                string Myquery = "SELECT * FROM PRODUCTTB";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                guna2DataGridView1.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UpdateScreen U1 = new UpdateScreen();
            U1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoginScreen L1 = new LoginScreen();
            L1.Show(); 
        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            AddScreen A1 = new AddScreen();
            A1.Show(); 
        }

        private void Delete_Button_Click(object sender, EventArgs e)
        {
            DeleteScreen D1 = new DeleteScreen();
            D1.Show();
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void MainMenu_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sMDBDataSet.ProductTB' table. You can move, or remove it, as needed.
            //this.productTBTableAdapter.Fill(this.sMDBDataSet.ProductTB);
            populate();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
