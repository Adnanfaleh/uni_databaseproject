﻿namespace DBProject
{
    partial class AddScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.IDTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.PriceTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.QuantityTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.ComapnyTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.YearTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.NameTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CatergoryTB = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Add_Button = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 586);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 64);
            this.panel2.TabIndex = 2;
            // 
            // IDTB
            // 
            this.IDTB.BackColor = System.Drawing.SystemColors.Menu;
            this.IDTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IDTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDTB.ForeColor = System.Drawing.Color.Black;
            this.IDTB.HintForeColor = System.Drawing.Color.Empty;
            this.IDTB.HintText = "";
            this.IDTB.isPassword = false;
            this.IDTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.IDTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.IDTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.IDTB.LineThickness = 3;
            this.IDTB.Location = new System.Drawing.Point(97, 232);
            this.IDTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.IDTB.Name = "IDTB";
            this.IDTB.Size = new System.Drawing.Size(233, 36);
            this.IDTB.TabIndex = 3;
            this.IDTB.Text = "ID";
            this.IDTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.IDTB.OnValueChanged += new System.EventHandler(this.bunifuMaterialTextbox1_OnValueChanged);
            // 
            // PriceTB
            // 
            this.PriceTB.BackColor = System.Drawing.SystemColors.Menu;
            this.PriceTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PriceTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceTB.ForeColor = System.Drawing.Color.Black;
            this.PriceTB.HintForeColor = System.Drawing.Color.Empty;
            this.PriceTB.HintText = "";
            this.PriceTB.isPassword = false;
            this.PriceTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.PriceTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.PriceTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.PriceTB.LineThickness = 3;
            this.PriceTB.Location = new System.Drawing.Point(383, 304);
            this.PriceTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.PriceTB.Name = "PriceTB";
            this.PriceTB.Size = new System.Drawing.Size(233, 36);
            this.PriceTB.TabIndex = 4;
            this.PriceTB.Text = "Price\n";
            this.PriceTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // QuantityTB
            // 
            this.QuantityTB.BackColor = System.Drawing.SystemColors.Menu;
            this.QuantityTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.QuantityTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityTB.ForeColor = System.Drawing.Color.Black;
            this.QuantityTB.HintForeColor = System.Drawing.Color.Empty;
            this.QuantityTB.HintText = "";
            this.QuantityTB.isPassword = false;
            this.QuantityTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.QuantityTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.QuantityTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.QuantityTB.LineThickness = 3;
            this.QuantityTB.Location = new System.Drawing.Point(383, 232);
            this.QuantityTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.QuantityTB.Name = "QuantityTB";
            this.QuantityTB.Size = new System.Drawing.Size(233, 36);
            this.QuantityTB.TabIndex = 5;
            this.QuantityTB.Text = "Quantity";
            this.QuantityTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.QuantityTB.OnValueChanged += new System.EventHandler(this.bunifuMaterialTextbox3_OnValueChanged);
            // 
            // ComapnyTB
            // 
            this.ComapnyTB.BackColor = System.Drawing.SystemColors.Menu;
            this.ComapnyTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ComapnyTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComapnyTB.ForeColor = System.Drawing.Color.Black;
            this.ComapnyTB.HintForeColor = System.Drawing.Color.Empty;
            this.ComapnyTB.HintText = "";
            this.ComapnyTB.isPassword = false;
            this.ComapnyTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.ComapnyTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.ComapnyTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.ComapnyTB.LineThickness = 3;
            this.ComapnyTB.Location = new System.Drawing.Point(97, 465);
            this.ComapnyTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.ComapnyTB.Name = "ComapnyTB";
            this.ComapnyTB.Size = new System.Drawing.Size(233, 36);
            this.ComapnyTB.TabIndex = 6;
            this.ComapnyTB.Text = "Company";
            this.ComapnyTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ComapnyTB.OnValueChanged += new System.EventHandler(this.bunifuMaterialTextbox4_OnValueChanged);
            // 
            // YearTB
            // 
            this.YearTB.BackColor = System.Drawing.SystemColors.Menu;
            this.YearTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.YearTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.YearTB.ForeColor = System.Drawing.Color.Black;
            this.YearTB.HintForeColor = System.Drawing.Color.Empty;
            this.YearTB.HintText = "";
            this.YearTB.isPassword = false;
            this.YearTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.YearTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.YearTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.YearTB.LineThickness = 3;
            this.YearTB.Location = new System.Drawing.Point(97, 384);
            this.YearTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.YearTB.Name = "YearTB";
            this.YearTB.Size = new System.Drawing.Size(233, 36);
            this.YearTB.TabIndex = 7;
            this.YearTB.Text = "Year \n";
            this.YearTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.YearTB.OnValueChanged += new System.EventHandler(this.bunifuMaterialTextbox5_OnValueChanged);
            // 
            // NameTB
            // 
            this.NameTB.BackColor = System.Drawing.SystemColors.Menu;
            this.NameTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NameTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameTB.ForeColor = System.Drawing.Color.Black;
            this.NameTB.HintForeColor = System.Drawing.Color.Empty;
            this.NameTB.HintText = "";
            this.NameTB.isPassword = false;
            this.NameTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.NameTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.NameTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.NameTB.LineThickness = 3;
            this.NameTB.Location = new System.Drawing.Point(97, 304);
            this.NameTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.NameTB.Name = "NameTB";
            this.NameTB.Size = new System.Drawing.Size(233, 36);
            this.NameTB.TabIndex = 8;
            this.NameTB.Text = "Name";
            this.NameTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumBlue;
            this.label3.Location = new System.Drawing.Point(30, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(411, 39);
            this.label3.TabIndex = 9;
            this.label3.Text = "Enter Product Details: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MediumBlue;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(387, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Screen";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.MediumBlue;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(207, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(569, 49);
            this.label2.TabIndex = 1;
            this.label2.Text = "STOCK MANAGMENT SYSTEM";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumBlue;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 135);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // CatergoryTB
            // 
            this.CatergoryTB.BackColor = System.Drawing.SystemColors.Menu;
            this.CatergoryTB.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CatergoryTB.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatergoryTB.ForeColor = System.Drawing.Color.Black;
            this.CatergoryTB.HintForeColor = System.Drawing.Color.Empty;
            this.CatergoryTB.HintText = "";
            this.CatergoryTB.isPassword = false;
            this.CatergoryTB.LineFocusedColor = System.Drawing.Color.Blue;
            this.CatergoryTB.LineIdleColor = System.Drawing.Color.MediumBlue;
            this.CatergoryTB.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.CatergoryTB.LineThickness = 3;
            this.CatergoryTB.Location = new System.Drawing.Point(383, 384);
            this.CatergoryTB.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.CatergoryTB.Name = "CatergoryTB";
            this.CatergoryTB.Size = new System.Drawing.Size(233, 36);
            this.CatergoryTB.TabIndex = 10;
            this.CatergoryTB.Text = "Category";
            this.CatergoryTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Add_Button
            // 
            this.Add_Button.BackColor = System.Drawing.Color.Green;
            this.Add_Button.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Button.ForeColor = System.Drawing.SystemColors.Control;
            this.Add_Button.Location = new System.Drawing.Point(586, 465);
            this.Add_Button.Name = "Add_Button";
            this.Add_Button.Size = new System.Drawing.Size(164, 70);
            this.Add_Button.TabIndex = 11;
            this.Add_Button.Text = "Add";
            this.Add_Button.UseVisualStyleBackColor = false;
            this.Add_Button.Click += new System.EventHandler(this.Add_Button_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumBlue;
            this.button1.Font = new System.Drawing.Font("Gadugi", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(765, 465);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 70);
            this.button1.TabIndex = 12;
            this.button1.Text = "Main Menu";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AddScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Add_Button);
            this.Controls.Add(this.CatergoryTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.NameTB);
            this.Controls.Add(this.YearTB);
            this.Controls.Add(this.ComapnyTB);
            this.Controls.Add(this.QuantityTB);
            this.Controls.Add(this.PriceTB);
            this.Controls.Add(this.IDTB);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddScreen";
            this.Load += new System.EventHandler(this.AddScreen_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox IDTB;
        private Bunifu.Framework.UI.BunifuMaterialTextbox PriceTB;
        private Bunifu.Framework.UI.BunifuMaterialTextbox QuantityTB;
        private Bunifu.Framework.UI.BunifuMaterialTextbox ComapnyTB;
        private Bunifu.Framework.UI.BunifuMaterialTextbox YearTB;
        private Bunifu.Framework.UI.BunifuMaterialTextbox NameTB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox CatergoryTB;
        private System.Windows.Forms.Button Add_Button;
        private System.Windows.Forms.Button button1;
    }
}