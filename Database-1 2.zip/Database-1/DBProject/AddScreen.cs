﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 

namespace DBProject
{
    public partial class AddScreen : Form
    {
        public AddScreen()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mmza1\source\repos\DBProject\DBProject\SMDB.mdf;Integrated Security=True;Connect Timeout=30;");

        private void label3_Click(object sender, EventArgs e)
        {

        }



        private void label3_Click_1(object sender, EventArgs e)
        {
          
        }

        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox4_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox3_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void bunifuMaterialTextbox5_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
           
                int id = int.Parse(IDTB.Text);
                string name = NameTB.Text;
                int year = int.Parse(YearTB.Text);
                string company = ComapnyTB.Text;
                int price = int.Parse(PriceTB.Text);
                int quantity = int.Parse(QuantityTB.Text);
                int categoryID = int.Parse(CatergoryTB.Text);

            if (IsProductIDExists(id))
            {
                MessageBox.Show("Product with ID " + id + " already exists in the system.");
                return; 
            }

            string query = @"INSERT INTO [dbo].[ProductTB]
                        ([ID], [Name], [Year], [Company], [Price], [Quantity], [CategoryID])
                        VALUES 
                        (" + id + ", '" + name + "', " + year + ", '" + company + "', " + price + ", " + quantity + ", " + categoryID + ")";

              
                SqlCommand cmd = new SqlCommand(query, con);

               cmd.Parameters.AddWithValue("@ID", id);
               cmd.Parameters.AddWithValue("@Name", name);
               cmd.Parameters.AddWithValue("@Year", year);
               cmd.Parameters.AddWithValue("@Company", company);
               cmd.Parameters.AddWithValue("@Price", price);
               cmd.Parameters.AddWithValue("@Quantity", quantity);
               cmd.Parameters.AddWithValue("@CategoryID", categoryID);

                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("User Successfully Added");
                con.Close();
        }

        private bool IsProductIDExists(int id)
        {
            string query = "SELECT COUNT(*) FROM [dbo].[ProductTB] WHERE [ID] = @ID";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@ID", id);
            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            return count > 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainMenu M1 = new MainMenu();
            M1.Show(); 
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
