﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBProject
{
    public partial class DeleteScreen : Form
    {
        public DeleteScreen()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mmza1\source\repos\DBProject\DBProject\SMDB.mdf;Integrated Security=True;Connect Timeout=30;");
        private void button1_Click(object sender, EventArgs e)
        {
            MainMenu M2 = new MainMenu();   
            M2.Show();  
        }
        void populate()
        {
            try
            {
                Con.Open();
                string Myquery = "SELECT * FROM PRODUCTTB";
                SqlDataAdapter da = new SqlDataAdapter(Myquery, Con);
                SqlCommandBuilder builder = new SqlCommandBuilder(da);
                var ds = new DataSet();
                da.Fill(ds);
                guna2DataGridView1.DataSource = ds.Tables[0];
                Con.Close();
            }
            catch { }
        }

        private bool IsProductIDExists(int id)
        {
            string query = "SELECT COUNT(*) FROM [dbo].[ProductTB] WHERE [ID] = @ID";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.Parameters.AddWithValue("@ID", id);
            Con.Open();
            int count = (int)cmd.ExecuteScalar();
            Con.Close();
            return count > 0;
        }
        private void bunifuMaterialTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void DeleteScreen_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sMDBDataSet.ProductTB' table. You can move, or remove it, as needed.
            //this.productTBTableAdapter.Fill(this.sMDBDataSet.ProductTB);
            populate();  
        }

        private void Delete_Button_Click(object sender, EventArgs e)
        {
            try
            {
                
                    int id = int.Parse(IDTB.Text); 

                if (!IsProductIDExists(id))
                    {
                        MessageBox.Show("Product with ID " + id + " does not exist in the system.");
                        return;
                    }

                    Con.Open();
                    string query = "DELETE FROM PRODUCTTB WHERE ID = @ID";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.ExecuteNonQuery();
                    Con.Close();

                    MessageBox.Show("Product deleted successfully.");
                    populate(); // Refresh the grid after deletion
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
